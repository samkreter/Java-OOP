/*
 * Sam Kreter
 * sakfy6
 * labc
 * hw3
 * 11/9/12
 * */
package sakfy6.cs3330.hw3;

public interface Creature {

	public boolean pickup(Item item);
	public boolean drop(Item item);
	public void dropAll();
	public CreatureResponse processCommand(String command,GameCreature creature,Item item);
	public void injured(int hp);
	public boolean attack(GameCreature creature, Item item);
	public boolean heal(Item item);
}
