/*
 * Sam Kreter
 * sakfy6
 * 11/27/14
 * labc
 * derf
 * 
 * */
package sakfy6.cs3330.lab7;


//interface for the flying animals 
public interface Flying {

	public void takeoff();

	public void land();
}
