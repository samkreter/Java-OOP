/*
 * Sam Kreter
 * sakfy6
 * 11/27/14
 * labc
 * derf
 * 
 * */
package sakfy6.cs3330.lab7;



public interface NonFlying {
	void movement();
}
