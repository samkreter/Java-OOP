/*
 * Sam kreter
 * sakfy6
 * 11/4/14
 * labC
 * I dont care
 * */

package sakfy6.cs3330.lab8;

public interface IsValidData {
	
	
	//interface methods 
	abstract void isValidAge();
	abstract void isName();
	abstract void isBalance();

}
